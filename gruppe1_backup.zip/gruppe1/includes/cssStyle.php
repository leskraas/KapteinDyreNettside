<?php
//Denne filen inneholder lenker til to .css filer
//Denne filen er inkludert i includer.php
//Alle filer som inkluderer includer.php vil dermed ha tilgang til disse to .css filene
?>

<link rel="stylesheet" type="text/css" href="./includes/table.css">
<link rel="stylesheet" type="text/css" href="./includes/mainStyle.css">
