<?php
//Denne filen oppretter en bunntekst, som er to linker til henholdsvis about.php og contact.php
//Denne filen burde includes med php-script der man ønsker å sette inn en footer (på bunn).
//include(includes/footer.php);
?>

<div class="footer">
	
	<ul class="nav">
	<li><a href="about.php">Om båtvakten</a><li>
	<li><a href="contact.php">Kontakt</a><li>
	</ul>
</div>


